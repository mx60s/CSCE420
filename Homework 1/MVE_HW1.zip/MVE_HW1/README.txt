Maggie von Ebers
CSCE 420
Homework 1
1/31/2019

These programs were built and tested in Python 3.7.2 using the Python3 command but they should work 
fine in Python 3.6.

Each one is run as "python3 filename.py" and input is given as specified in the given instruction file.
So, the first input is the length of the array and the rest of the inputs are each number of the array
followed by the enter key.